package com.projek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
